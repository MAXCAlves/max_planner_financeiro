// Conteúdo simulado do arquivo: relatorioPDF.js
// Local: utils