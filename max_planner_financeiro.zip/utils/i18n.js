// Conteúdo simulado do arquivo: i18n.js
// Local: utils