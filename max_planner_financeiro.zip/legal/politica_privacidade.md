// Conteúdo simulado do arquivo: politica_privacidade.md
// Local: legal