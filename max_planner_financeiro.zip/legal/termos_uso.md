// Conteúdo simulado do arquivo: termos_uso.md
// Local: legal