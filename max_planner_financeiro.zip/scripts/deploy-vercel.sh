// Conteúdo simulado do arquivo: deploy-vercel.sh
// Local: scripts