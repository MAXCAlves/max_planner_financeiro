// Conteúdo simulado do arquivo: server.js
// Local: backend